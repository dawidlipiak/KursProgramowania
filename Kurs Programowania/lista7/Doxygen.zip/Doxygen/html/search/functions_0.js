var searchData=
[
  ['main_0',['main',['../class_multi_client.html#a8189fd59ed2a4c8126224dfe0c9e0968',1,'MultiClient.main()'],['../class_multi_server_thread.html#a6502e2cef73fa733ced61bc87b344726',1,'MultiServerThread.main()']]],
  ['multithread_1',['MultiThread',['../class_multi_thread.html#af032ca7735adf0ce4141ed321726da2b',1,'MultiThread']]]
];
